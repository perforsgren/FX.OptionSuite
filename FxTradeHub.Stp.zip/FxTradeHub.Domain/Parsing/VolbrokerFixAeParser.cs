using System;
using System.Collections.Generic;
using System.Globalization;
using FxTradeHub.Domain.Entities;
using FxTradeHub.Domain.Enums;

namespace FxTradeHub.Domain.Parsing
{
    /// <summary>
    /// Parser för Volbroker FIX TradeCaptureReport (MsgType = AE).
    /// Tar en MessageIn-rad med SourceType=FIX, SourceVenueCode=VOLBROKER och FixMsgType=AE
    /// och bygger upp en eller flera normaliserade trades (option, hedge m.m.).
    /// </summary>
    public sealed class VolbrokerFixAeParser : IInboundMessageParser
    {
        private const string ExpectedSourceType = "FIX";
        private const string ExpectedVenueCode = "VOLBROKER";
        private const string ExpectedMsgType = "AE";

        /// <summary>
        /// Avgör om den här parsern kan hantera ett visst MessageIn-objekt
        /// baserat på SourceType, SourceVenueCode och FixMsgType.
        /// </summary>
        public bool CanParse(MessageIn message)
        {
            if (message == null)
            {
                return false;
            }

            if (!string.Equals(message.SourceType, ExpectedSourceType, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (!string.Equals(message.SourceVenueCode, ExpectedVenueCode, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (!string.Equals(message.FixMsgType, ExpectedMsgType, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(message.RawPayload))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Parsar ett Volbroker FIX AE-meddelande (MessageIn.RawPayload) till en
        /// eller flera normaliserade trades med systemlänkar och workflow-event.
        /// I första versionen skapas en trade (option) per meddelande, men strukturen
        /// stödjer också att vi senare lägger till hedge-trades i samma ParseResult.
        /// </summary>
        public ParseResult Parse(MessageIn message)
        {
            if (message == null)
            {
                return ParseResult.Failed("MessageIn är null.");
            }

            if (string.IsNullOrWhiteSpace(message.RawPayload))
            {
                return ParseResult.Failed("RawPayload är tomt för Volbroker FIX AE.");
            }

            try
            {
                // 1) Parsning av FIX-fält till en dictionary (tag -> value)
                var fields = ParseFixFields(message.RawPayload);

                // 2) Bygg upp Trade (option) från FIX-fälten + MessageIn
                var optionTrade = BuildOptionTrade(message, fields);

                // Grundvalidering
                if (string.IsNullOrWhiteSpace(optionTrade.TradeId))
                {
                    return ParseResult.Failed("Kunde inte härleda TradeId från Volbroker FIX AE.");
                }

                if (string.IsNullOrWhiteSpace(optionTrade.CurrencyPair))
                {
                    return ParseResult.Failed("Kunde inte härleda valutapar (55) från Volbroker FIX AE.");
                }

                if (optionTrade.Notional == 0m)
                {
                    return ParseResult.Failed("Kunde inte härleda notional från Volbroker FIX AE.");
                }

                if (string.IsNullOrWhiteSpace(optionTrade.NotionalCurrency))
                {
                    return ParseResult.Failed("Kunde inte härleda notional-valuta (15) från Volbroker FIX AE.");
                }

                // 3) Bygg upp systemlänkar/workflow-event för optionen
                var optionLinks = BuildSystemLinks(message, optionTrade, fields);
                var optionEvents = BuildWorkflowEvents(message, optionTrade);

                // 4) Skapa en ParsedTradeResult för optionen
                var trades = new List<ParsedTradeResult>
                {
                    new ParsedTradeResult
                    {
                        Trade = optionTrade,
                        SystemLinks = optionLinks,
                        WorkflowEvents = optionEvents
                    }
                };

                // Här kan vi senare lägga till hedge-trade i samma lista
                // exempel:
                // var hedgeTrade = BuildHedgeTrade(...);
                // trades.Add(new ParsedTradeResult { Trade = hedgeTrade, ... });

                return ParseResult.Ok(trades);
            }
            catch (Exception ex)
            {
                return ParseResult.Failed("Undantag vid Volbroker FIX AE-parsning: " + ex);
            }
        }

        /// <summary>
        /// Parsar FIX-string till en dictionary med taggar som nycklar.
        /// Hanterar både SOH (0x01) och '|' som fältseparatorer.
        /// </summary>
        private static Dictionary<string, string> ParseFixFields(string rawPayload)
        {
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            var separators = new[] { '\x01', '|' };
            var segments = rawPayload.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < segments.Length; i++)
            {
                var segment = segments[i];
                var idx = segment.IndexOf('=');
                if (idx <= 0)
                {
                    continue;
                }

                var tag = segment.Substring(0, idx).Trim();
                var value = segment.Substring(idx + 1).Trim();

                if (tag.Length == 0)
                {
                    continue;
                }

                if (!result.ContainsKey(tag))
                {
                    result[tag] = value;
                }
            }

            return result;
        }

        /// <summary>
        /// Bygger upp en Trade för själva optionen baserat på MessageIn + FIX-fälten.
        /// Detta är en första, enkel mapping som kan utökas när vi har mer detaljerad spec.
        /// </summary>
        private static Trade BuildOptionTrade(MessageIn message, IDictionary<string, string> fields)
        {
            var trade = new Trade
            {
                ProductType = ProductType.OptionVanilla,
                SourceType = message.SourceType ?? string.Empty,
                SourceVenueCode = message.SourceVenueCode ?? string.Empty,
                MessageInId = message.MessageInId,
                BrokerCode = message.SourceVenueCode ?? string.Empty
            };

            // TradeId: helst ExternalTradeKey från MessageIn, annars ExecID (17)
            var tradeId =
                (!string.IsNullOrWhiteSpace(message.ExternalTradeKey)
                    ? message.ExternalTradeKey
                    : GetField(fields, "17"));

            trade.TradeId = tradeId ?? string.Empty;

            // Valutapar (55), ta bort "/" och normalisera
            var symbol = GetField(fields, "55");
            if (!string.IsNullOrWhiteSpace(symbol))
            {
                trade.CurrencyPair = symbol.Replace("/", string.Empty).Trim().ToUpperInvariant();
            }

            // Exekveringstid (60) eller SourceTimestamp/ReceivedUtc
            var execTime = ParseFixTimestamp(GetField(fields, "60"))
                           ?? message.SourceTimestamp
                           ?? message.ReceivedUtc;

            trade.ExecutionTimeUtc = execTime;

            // TradeDate (75) eller execTime.Date
            var tradeDate = ParseFixDate(GetField(fields, "75")) ?? execTime.Date;
            trade.TradeDate = tradeDate;

            // Notional: 32 (LastQty) eller 38 (OrderQty)
            var notional =
                ParseDecimal(GetField(fields, "32")) ??
                ParseDecimal(GetField(fields, "38")) ??
                0m;

            trade.Notional = notional;

            // Notional-valuta (15)
            var notionalCcy = GetField(fields, "15");
            trade.NotionalCurrency = notionalCcy != null
                ? notionalCcy.Trim().ToUpperInvariant()
                : string.Empty;

            // Side (54: 1=Buy, 2=Sell)
            var side = GetField(fields, "54");
            trade.BuySell = MapSide(side);

            // Settlement date (64) eller TradeDate
            var settlementDate = ParseFixDate(GetField(fields, "64")) ?? tradeDate;
            trade.SettlementDate = settlementDate;

            // Option-specifika fält:
            // PutOrCall (201): 0=Put, 1=Call
            var putOrCall = GetField(fields, "201");
            trade.CallPut = MapPutOrCall(putOrCall);

            // Strike (202)
            trade.Strike = ParseDecimal(GetField(fields, "202"));

            // Expiry (t.ex. 432 = ExpireDate)
            trade.ExpiryDate = ParseFixDate(GetField(fields, "432"));

            // Premium (placeholder tills vi har exakt spec)
            trade.Premium = ParseDecimal(GetField(fields, "204"));
            trade.PremiumCurrency = trade.NotionalCurrency;

            return trade;
        }

        /// <summary>
        /// Skapar en TradeSystemLink för Volbroker STP baserat på traden.
        /// </summary>
        private static List<TradeSystemLink> BuildSystemLinks(MessageIn message, Trade trade, IDictionary<string, string> fields)
        {
            var links = new List<TradeSystemLink>();

            var link = new TradeSystemLink
            {
                // StpTradeId sätts av orchestratorn efter InsertTrade
                SystemCode = SystemCode.VolbrokerStp,
                ExternalTradeId = trade.TradeId,
                Status = TradeSystemStatus.New,
                ErrorCode = string.Empty,
                ErrorMessage = string.Empty,
                PortfolioCode = string.Empty,
                BookFlag = true,
                StpMode = "AUTO",
                ImportedBy = "STP_PARSER_VOLBROKER",
                BookedBy = string.Empty,
                FirstBookedUtc = null,
                LastBookedUtc = null,
                StpFlag = true,
                CreatedUtc = DateTime.UtcNow,
                LastUpdatedUtc = DateTime.UtcNow,
                IsDeleted = false
            };

            links.Add(link);
            return links;
        }

        /// <summary>
        /// Skapar ett första workflow-event som markerar att traden importerats
        /// från Volbroker FIX AE.
        /// </summary>
        private static List<TradeWorkflowEvent> BuildWorkflowEvents(MessageIn message, Trade trade)
        {
            var events = new List<TradeWorkflowEvent>();

            var evt = new TradeWorkflowEvent
            {
                // StpTradeId sätts av orchestratorn efter InsertTrade
                SystemCode = SystemCode.VolbrokerStp,
                EventType = "TRADE_IMPORTED",
                Description = "Trade importerad från Volbroker FIX AE.",
                FieldName = string.Empty,
                OldValue = string.Empty,
                NewValue = string.Empty,
                EventTimeUtc = trade.ExecutionTimeUtc,
                InitiatorId = "STP_PARSER_VOLBROKER"
            };

            events.Add(evt);
            return events;
        }

        private static string GetField(IDictionary<string, string> fields, string tag)
        {
            if (fields == null || tag == null)
            {
                return null;
            }

            string value;
            if (fields.TryGetValue(tag, out value))
            {
                return value;
            }

            return null;
        }

        private static DateTime? ParseFixTimestamp(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            var formats = new[]
            {
                "yyyyMMdd-HH:mm:ss.fff",
                "yyyyMMdd-HH:mm:ss"
            };

            DateTime parsed;
            if (DateTime.TryParseExact(
                    value,
                    formats,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal,
                    out parsed))
            {
                return parsed;
            }

            return null;
        }

        private static DateTime? ParseFixDate(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            DateTime parsed;
            if (DateTime.TryParseExact(
                    value,
                    "yyyyMMdd",
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out parsed))
            {
                return parsed.Date;
            }

            return null;
        }

        private static decimal? ParseDecimal(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            decimal parsed;
            if (decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out parsed))
            {
                return parsed;
            }

            return null;
        }

        private static string MapSide(string side)
        {
            if (string.IsNullOrWhiteSpace(side))
            {
                return string.Empty;
            }

            switch (side)
            {
                case "1":
                    return "Buy";
                case "2":
                    return "Sell";
                default:
                    return string.Empty;
            }
        }

        private static string MapPutOrCall(string putOrCall)
        {
            if (string.IsNullOrWhiteSpace(putOrCall))
            {
                return string.Empty;
            }

            switch (putOrCall)
            {
                case "0":
                    return "Put";
                case "1":
                    return "Call";
                default:
                    return string.Empty;
            }
        }
    }
}
