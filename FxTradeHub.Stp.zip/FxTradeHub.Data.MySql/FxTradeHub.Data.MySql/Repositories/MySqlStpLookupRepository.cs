using System;
using System.Data;
using FxTradeHub.Domain.Entities;
using FxTradeHub.Domain.Interfaces;
using MySql.Data.MySqlClient;

namespace FxTradeHub.Data.MySql.Repositories
{
    /// <summary>
    /// MySQL-implementation av IStpLookupRepository mot schemat trade_stp.
    /// Hanterar lookup-tabeller för expiry cut per valutapar,
    /// Calypso-bok per trader och broker-mapping.
    /// </summary>
    public sealed class MySqlStpLookupRepository : IStpLookupRepository
    {
        private readonly string _connectionString;

        /// <summary>
        /// Skapar ett nytt lookup-repository med given connection string.
        /// Exempel:
        /// "Server=srv78506;Port=3306;Database=trade_stp;User Id=fxopt;Password=...;SslMode=None;TreatTinyAsBoolean=false;"
        /// </summary>
        /// <param name="connectionString">Connection string mot trade_stp-databasen.</param>
        public MySqlStpLookupRepository(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new ArgumentException("Connection string must not be empty.", "connectionString");

            _connectionString = connectionString;
        }

        /// <summary>
        /// Skapar en ny MySqlConnection mot trade_stp.
        /// </summary>
        /// <returns>Öppen MySqlConnection (ej öppnad).</returns>
        private MySqlConnection CreateConnection()
        {
            return new MySqlConnection(_connectionString);
        }

        /// <summary>
        /// Hämtar expiry cut-regel för ett givet valutapar.
        /// Returnerar null om ingen aktiv regel finns.
        /// </summary>
        /// <param name="currencyPair">Valutapar, t.ex. EURSEK.</param>
        /// <returns>ExpiryCutCcyRule eller null.</returns>
        public ExpiryCutCcyRule GetExpiryCutByCurrencyPair(string currencyPair)
        {
            if (string.IsNullOrWhiteSpace(currencyPair))
            {
                return null;
            }

            const string sql = @"
SELECT
    CurrencyPair,
    ExpiryCut,
    IsActive,
    Comment,
    CreatedUtc,
    UpdatedUtc,
    UpdatedBy
FROM trade_stp.stp_expiry_cut_ccy
WHERE CurrencyPair = @CurrencyPair
LIMIT 1;";

            using (var connection = CreateConnection())
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    command.CommandType = CommandType.Text;

                    command.Parameters.Add("@CurrencyPair", MySqlDbType.VarChar, 20).Value = currencyPair;

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return null;
                        }

                        return MapExpiryCutCcyRule(reader);
                    }
                }
            }
        }

        /// <summary>
        /// Hämtar Calypso-bok-regel för en given trader.
        /// Returnerar null om ingen aktiv regel finns.
        /// </summary>
        /// <param name="traderId">TraderId / användar-id.</param>
        /// <returns>CalypsoBookUserRule eller null.</returns>
        public CalypsoBookUserRule GetCalypsoBookByTraderId(string traderId)
        {
            if (string.IsNullOrWhiteSpace(traderId))
            {
                return null;
            }

            const string sql = @"
SELECT
    TraderId,
    CalypsoBook,
    IsActive,
    Comment,
    CreatedUtc,
    UpdatedUtc,
    UpdatedBy
FROM trade_stp.stp_calypso_book_user
WHERE TraderId = @TraderId
LIMIT 1;";

            using (var connection = CreateConnection())
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    command.CommandType = CommandType.Text;

                    command.Parameters.Add("@TraderId", MySqlDbType.VarChar, 50).Value = traderId;

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return null;
                        }

                        return MapCalypsoBookUserRule(reader);
                    }
                }
            }
        }

        /// <summary>
        /// Hämtar broker-mapping för en given venue och extern brokerkod.
        /// Returnerar null om ingen aktiv mappning finns.
        /// </summary>
        /// <param name="sourceVenueCode">Venue/källa, t.ex. VOLBROKER.</param>
        /// <param name="externalBrokerCode">Extern brokerkod från meddelandet.</param>
        /// <returns>BrokerMapping eller null.</returns>
        public BrokerMapping GetBrokerMapping(string sourceVenueCode, string externalBrokerCode)
        {
            if (string.IsNullOrWhiteSpace(sourceVenueCode) || string.IsNullOrWhiteSpace(externalBrokerCode))
            {
                return null;
            }

            const string sql = @"
SELECT
    Id,
    SourceVenueCode,
    ExternalBrokerCode,
    NormalizedBrokerCode,
    IsActive,
    Comment,
    CreatedUtc,
    UpdatedUtc,
    UpdatedBy
FROM trade_stp.stp_broker_mapping
WHERE SourceVenueCode = @SourceVenueCode
  AND ExternalBrokerCode = @ExternalBrokerCode
LIMIT 1;";

            using (var connection = CreateConnection())
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    command.CommandType = CommandType.Text;

                    command.Parameters.Add("@SourceVenueCode", MySqlDbType.VarChar, 50).Value = sourceVenueCode;
                    command.Parameters.Add("@ExternalBrokerCode", MySqlDbType.VarChar, 100).Value = externalBrokerCode;

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return null;
                        }

                        return MapBrokerMapping(reader);
                    }
                }
            }
        }

        /// <summary>
        /// Mappar en datareader-rad till ExpiryCutCcyRule.
        /// </summary>
        /// <param name="reader">Datareader positionerad på en rad.</param>
        /// <returns>ExpiryCutCcyRule-instans.</returns>
        private static ExpiryCutCcyRule MapExpiryCutCcyRule(IDataRecord reader)
        {
            var rule = new ExpiryCutCcyRule
            {
                CurrencyPair = reader["CurrencyPair"] as string ?? string.Empty,
                ExpiryCut = reader["ExpiryCut"] as string ?? string.Empty,
                IsActive = Convert.ToBoolean(reader["IsActive"]),
                Comment = reader["Comment"] as string ?? string.Empty,
                CreatedUtc = reader.GetDateTime(reader.GetOrdinal("CreatedUtc")),
                UpdatedBy = reader["UpdatedBy"] as string ?? string.Empty
            };

            int indexUpdatedUtc = reader.GetOrdinal("UpdatedUtc");
            if (reader.IsDBNull(indexUpdatedUtc))
            {
                rule.UpdatedUtc = null;
            }
            else
            {
                rule.UpdatedUtc = reader.GetDateTime(indexUpdatedUtc);
            }

            return rule;
        }

        /// <summary>
        /// Mappar en datareader-rad till CalypsoBookUserRule.
        /// </summary>
        /// <param name="reader">Datareader positionerad på en rad.</param>
        /// <returns>CalypsoBookUserRule-instans.</returns>
        private static CalypsoBookUserRule MapCalypsoBookUserRule(IDataRecord reader)
        {
            var rule = new CalypsoBookUserRule
            {
                TraderId = reader["TraderId"] as string ?? string.Empty,
                CalypsoBook = reader["CalypsoBook"] as string ?? string.Empty,
                IsActive = Convert.ToBoolean(reader["IsActive"]),
                Comment = reader["Comment"] as string ?? string.Empty,
                CreatedUtc = reader.GetDateTime(reader.GetOrdinal("CreatedUtc")),
                UpdatedBy = reader["UpdatedBy"] as string ?? string.Empty
            };

            int indexUpdatedUtc = reader.GetOrdinal("UpdatedUtc");
            if (reader.IsDBNull(indexUpdatedUtc))
            {
                rule.UpdatedUtc = null;
            }
            else
            {
                rule.UpdatedUtc = reader.GetDateTime(indexUpdatedUtc);
            }

            return rule;
        }

        /// <summary>
        /// Mappar en datareader-rad till BrokerMapping.
        /// </summary>
        /// <param name="reader">Datareader positionerad på en rad.</param>
        /// <returns>BrokerMapping-instans.</returns>
        private static BrokerMapping MapBrokerMapping(IDataRecord reader)
        {
            var mapping = new BrokerMapping
            {
                Id = Convert.ToInt64(reader["Id"]),
                SourceVenueCode = reader["SourceVenueCode"] as string ?? string.Empty,
                ExternalBrokerCode = reader["ExternalBrokerCode"] as string ?? string.Empty,
                NormalizedBrokerCode = reader["NormalizedBrokerCode"] as string ?? string.Empty,
                IsActive = Convert.ToBoolean(reader["IsActive"]),
                Comment = reader["Comment"] as string ?? string.Empty,
                CreatedUtc = reader.GetDateTime(reader.GetOrdinal("CreatedUtc")),
                UpdatedBy = reader["UpdatedBy"] as string ?? string.Empty
            };

            int indexUpdatedUtc = reader.GetOrdinal("UpdatedUtc");
            if (reader.IsDBNull(indexUpdatedUtc))
            {
                mapping.UpdatedUtc = null;
            }
            else
            {
                mapping.UpdatedUtc = reader.GetDateTime(indexUpdatedUtc);
            }

            return mapping;
        }
    }
}
